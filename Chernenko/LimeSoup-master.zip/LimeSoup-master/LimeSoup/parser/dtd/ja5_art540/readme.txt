Downloaded from:
https://www.elsevier.com/authors/author-schemas/elsevier-xml-dtds-and-transport-schemas-2#DTD-5.4.0
https://www.elsevier.com/__data/assets/file/0004/58873/ja5_art540.zip
